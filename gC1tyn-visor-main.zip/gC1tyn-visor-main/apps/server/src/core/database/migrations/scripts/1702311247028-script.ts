import { MigrationInterface, QueryRunner } from 'typeorm'

export class Script1702311247028 implements MigrationInterface {
  name = 'Script1702311247028'

  public async up(queryRunner: QueryRunner): Promise<void> {
    try {
      await queryRunner.query(
        `
        INSERT INTO "user" ("id", "email", "name", "pictureUrl", "status", "password") VALUES ('9a388b13-9e1a-4b6f-9289-dbcd02514b0c', '1Gia_Buckridge@yahoo.com', 'David Brown', 'https://i.imgur.com/YfJQV5z.png?id=3', 'deleted', '$2b$10$ppubsZypHzkqW9dkhMB97ul2.wSsvaCoDE2CzqIHygddRMKXvpYUC');
INSERT INTO "user" ("id", "email", "name", "pictureUrl", "status", "password") VALUES ('8b98ee2d-5a8b-4de3-a799-f1fc3fa048c2', '7Chad8@gmail.com', 'Eva Green', 'https://i.imgur.com/YfJQV5z.png?id=9', 'pending', '$2b$10$ppubsZypHzkqW9dkhMB97ul2.wSsvaCoDE2CzqIHygddRMKXvpYUC');
INSERT INTO "user" ("id", "email", "name", "pictureUrl", "status", "password") VALUES ('bf442c98-1d03-4755-8a3d-8163060119e8', '13Elmore.Vandervort@hotmail.com', 'Bob Johnson', 'https://i.imgur.com/YfJQV5z.png?id=15', 'suspended', '$2b$10$ppubsZypHzkqW9dkhMB97ul2.wSsvaCoDE2CzqIHygddRMKXvpYUC');
INSERT INTO "user" ("id", "email", "name", "pictureUrl", "status", "password") VALUES ('b8e1d22b-1f72-43b0-99d2-8514f6a3ccdf', '19Jena.Leannon@gmail.com', 'Eva Green', 'https://i.imgur.com/YfJQV5z.png?id=21', 'deleted', '$2b$10$ppubsZypHzkqW9dkhMB97ul2.wSsvaCoDE2CzqIHygddRMKXvpYUC');
INSERT INTO "user" ("id", "email", "name", "pictureUrl", "status", "password") VALUES ('31ac51e1-ff56-4ef4-a99c-472b07690a0c', '25Orland_Wisoky@yahoo.com', 'Bob Johnson', 'https://i.imgur.com/YfJQV5z.png?id=27', 'pending', '$2b$10$ppubsZypHzkqW9dkhMB97ul2.wSsvaCoDE2CzqIHygddRMKXvpYUC');
INSERT INTO "user" ("id", "email", "name", "pictureUrl", "status", "password") VALUES ('23f9ba14-c951-4f7e-8980-aca8c61edcd6', '37Domenica8@yahoo.com', 'David Brown', 'https://i.imgur.com/YfJQV5z.png?id=39', 'active', '$2b$10$ppubsZypHzkqW9dkhMB97ul2.wSsvaCoDE2CzqIHygddRMKXvpYUC');
INSERT INTO "user" ("id", "email", "name", "pictureUrl", "status", "password") VALUES ('eed734ce-c74b-4203-8d39-e21cf89bbdcb', '43Nakia_Dicki53@hotmail.com', 'Eva Green', 'https://i.imgur.com/YfJQV5z.png?id=45', 'inactive', '$2b$10$ppubsZypHzkqW9dkhMB97ul2.wSsvaCoDE2CzqIHygddRMKXvpYUC');
INSERT INTO "user" ("id", "email", "name", "pictureUrl", "status", "password") VALUES ('1c7724b6-a4cb-4dd2-8127-8ca3f0d217cd', '49Dorthy71@yahoo.com', 'Alice Smith', 'https://i.imgur.com/YfJQV5z.png?id=51', 'active', '$2b$10$ppubsZypHzkqW9dkhMB97ul2.wSsvaCoDE2CzqIHygddRMKXvpYUC');
INSERT INTO "user" ("id", "email", "name", "pictureUrl", "status", "password") VALUES ('d5c3a27b-6fc1-4884-9763-65d0c8b63589', '55Britney66@hotmail.com', 'Carol White', 'https://i.imgur.com/YfJQV5z.png?id=57', 'suspended', '$2b$10$ppubsZypHzkqW9dkhMB97ul2.wSsvaCoDE2CzqIHygddRMKXvpYUC');

INSERT INTO "notification" ("id", "title", "message", "senderName", "senderEmail", "senderPictureUrl", "redirectUrl", "userId") VALUES ('95c75687-d19e-47ce-ab4d-bf5b40f50eba', 'Special Offer for You', 'Exclusive offer Upgrade your plan for more features.', 'John Doe', '64Judah.Stoltenberg89@gmail.com', 'https://i.imgur.com/YfJQV5z.png?id=65', 'https://i.imgur.com/YfJQV5z.png?id=66', 'eed734ce-c74b-4203-8d39-e21cf89bbdcb');
INSERT INTO "notification" ("id", "title", "message", "senderName", "senderEmail", "senderPictureUrl", "redirectUrl", "userId") VALUES ('9663d9a5-9614-4f73-b469-2be04f25f6e2', 'Welcome to Our Service', 'Your website details have been updated.', 'Mike Brown', '71Jettie.Prohaska37@yahoo.com', 'https://i.imgur.com/YfJQV5z.png?id=72', 'https://i.imgur.com/YfJQV5z.png?id=73', 'd5c3a27b-6fc1-4884-9763-65d0c8b63589');
INSERT INTO "notification" ("id", "title", "message", "senderName", "senderEmail", "senderPictureUrl", "redirectUrl", "userId") VALUES ('1f5d8c11-10e6-4233-a36e-d49937cf6736', 'Special Offer for You', 'Dont forget to update your website details to stay current.', 'Mike Brown', '78Erwin_Fritsch@yahoo.com', 'https://i.imgur.com/YfJQV5z.png?id=79', 'https://i.imgur.com/YfJQV5z.png?id=80', '21a857f1-ba5f-4435-bcf6-f910ec07c0dc');
INSERT INTO "notification" ("id", "title", "message", "senderName", "senderEmail", "senderPictureUrl", "redirectUrl", "userId") VALUES ('38c6ad15-7d60-4848-af00-1314dc223d7a', 'New Website Submission', 'Your website details have been updated.', 'John Doe', '85Guy50@yahoo.com', 'https://i.imgur.com/YfJQV5z.png?id=86', 'https://i.imgur.com/YfJQV5z.png?id=87', '8b98ee2d-5a8b-4de3-a799-f1fc3fa048c2');
INSERT INTO "notification" ("id", "title", "message", "senderName", "senderEmail", "senderPictureUrl", "redirectUrl", "userId") VALUES ('05b40dd7-d3ee-4aca-95cb-3e4830db9384', 'Special Offer for You', 'Dont forget to update your website details to stay current.', 'David Smith', '92Derick33@yahoo.com', 'https://i.imgur.com/YfJQV5z.png?id=93', 'https://i.imgur.com/YfJQV5z.png?id=94', 'd5c3a27b-6fc1-4884-9763-65d0c8b63589');
INSERT INTO "notification" ("id", "title", "message", "senderName", "senderEmail", "senderPictureUrl", "redirectUrl", "userId") VALUES ('cd5a1140-0b2d-49b7-810f-8560e3f69f39', 'New Website Submission', 'Exclusive offer Upgrade your plan for more features.', 'Mike Brown', '99Shawn_Roob@yahoo.com', 'https://i.imgur.com/YfJQV5z.png?id=100', 'https://i.imgur.com/YfJQV5z.png?id=101', 'd5c3a27b-6fc1-4884-9763-65d0c8b63589');
INSERT INTO "notification" ("id", "title", "message", "senderName", "senderEmail", "senderPictureUrl", "redirectUrl", "userId") VALUES ('3464d685-3bcf-4e5f-a301-c2b4c5164dac', 'Welcome to Our Service', 'Your website has been successfully added to our directory.', 'John Doe', '106Myrtice39@gmail.com', 'https://i.imgur.com/YfJQV5z.png?id=107', 'https://i.imgur.com/YfJQV5z.png?id=108', '9a388b13-9e1a-4b6f-9289-dbcd02514b0c');
INSERT INTO "notification" ("id", "title", "message", "senderName", "senderEmail", "senderPictureUrl", "redirectUrl", "userId") VALUES ('9ff4e7d4-e47a-4bec-ae42-b5b2fd8c8fc9', 'Special Offer for You', 'Your website details have been updated.', 'Mike Brown', '113Lonny.Marvin@yahoo.com', 'https://i.imgur.com/YfJQV5z.png?id=114', 'https://i.imgur.com/YfJQV5z.png?id=115', '21a857f1-ba5f-4435-bcf6-f910ec07c0dc');
INSERT INTO "notification" ("id", "title", "message", "senderName", "senderEmail", "senderPictureUrl", "redirectUrl", "userId") VALUES ('4593bdc9-5855-463c-9944-3ec2acca2747', 'Welcome to Our Service', 'Dont forget to update your website details to stay current.', 'Mike Brown', '120Genevieve6@hotmail.com', 'https://i.imgur.com/YfJQV5z.png?id=121', 'https://i.imgur.com/YfJQV5z.png?id=122', '8b98ee2d-5a8b-4de3-a799-f1fc3fa048c2');
INSERT INTO "notification" ("id", "title", "message", "senderName", "senderEmail", "senderPictureUrl", "redirectUrl", "userId") VALUES ('0cfc857e-e218-4a7c-995d-5a2f633e9764', 'Reminder Profile Update', 'Exclusive offer Upgrade your plan for more features.', 'Alice Johnson', '127Neal_Veum@gmail.com', 'https://i.imgur.com/YfJQV5z.png?id=128', 'https://i.imgur.com/YfJQV5z.png?id=129', '1c7724b6-a4cb-4dd2-8127-8ca3f0d217cd');

INSERT INTO "website" ("id", "url", "description", "userId") VALUES ('8f17f180-0463-4402-85d2-61deacc2a53c', 'https://i.imgur.com/YfJQV5z.png?id=131', 'Cuttingedge technology news and industry updates.', '1c7724b6-a4cb-4dd2-8127-8ca3f0d217cd');
INSERT INTO "website" ("id", "url", "description", "userId") VALUES ('5aebe921-3705-49a3-b60b-aeb343dd896f', 'https://i.imgur.com/YfJQV5z.png?id=134', 'A platform for artists to showcase their work and connect with other creatives.', '31ac51e1-ff56-4ef4-a99c-472b07690a0c');
INSERT INTO "website" ("id", "url", "description", "userId") VALUES ('44b2b1f1-5c96-4d7f-ad65-793383243fcd', 'https://i.imgur.com/YfJQV5z.png?id=137', 'Cuttingedge technology news and industry updates.', '21a857f1-ba5f-4435-bcf6-f910ec07c0dc');
INSERT INTO "website" ("id", "url", "description", "userId") VALUES ('1dd324e5-73ec-4642-bee7-f316589e9286', 'https://i.imgur.com/YfJQV5z.png?id=140', 'A platform for artists to showcase their work and connect with other creatives.', 'd5c3a27b-6fc1-4884-9763-65d0c8b63589');
INSERT INTO "website" ("id", "url", "description", "userId") VALUES ('b23c859c-edee-49d9-b4e4-f56afd080db5', 'https://i.imgur.com/YfJQV5z.png?id=143', 'A leading source for reliable news and updated analysis.', 'eed734ce-c74b-4203-8d39-e21cf89bbdcb');
INSERT INTO "website" ("id", "url", "description", "userId") VALUES ('2ac31d75-cb35-4343-ac9b-29a1f65cd527', 'https://i.imgur.com/YfJQV5z.png?id=146', 'Explore the worlds most thrilling adventures and travel destinations.', 'eed734ce-c74b-4203-8d39-e21cf89bbdcb');
INSERT INTO "website" ("id", "url", "description", "userId") VALUES ('4f7b6450-a99c-49fd-8e55-ac3b9255b084', 'https://i.imgur.com/YfJQV5z.png?id=149', 'Tips and advice on living a healthy lifestyle.', '21a857f1-ba5f-4435-bcf6-f910ec07c0dc');
INSERT INTO "website" ("id", "url", "description", "userId") VALUES ('bffcb72a-a7c9-4440-b3a2-bdd2d2341f4b', 'https://i.imgur.com/YfJQV5z.png?id=152', 'A platform for artists to showcase their work and connect with other creatives.', 'd5c3a27b-6fc1-4884-9763-65d0c8b63589');
INSERT INTO "website" ("id", "url", "description", "userId") VALUES ('628e6d8d-85c1-41ec-a2ea-27ced856f591', 'https://i.imgur.com/YfJQV5z.png?id=155', 'A leading source for reliable news and updated analysis.', '21a857f1-ba5f-4435-bcf6-f910ec07c0dc');
INSERT INTO "website" ("id", "url", "description", "userId") VALUES ('42027a47-9e12-4919-85ad-776cf6af0485', 'https://i.imgur.com/YfJQV5z.png?id=158', 'A leading source for reliable news and updated analysis.', '21a857f1-ba5f-4435-bcf6-f910ec07c0dc');

INSERT INTO "image" ("id", "imageUrl", "websiteId") VALUES ('3251f385-9487-44a1-bc87-96d39bcb8b65', 'https://i.imgur.com/YfJQV5z.png?id=161', '1dd324e5-73ec-4642-bee7-f316589e9286');
INSERT INTO "image" ("id", "imageUrl", "websiteId") VALUES ('7b6b6b82-2230-4a6e-8f35-e4fcb4d5e7e8', 'https://i.imgur.com/YfJQV5z.png?id=163', '42027a47-9e12-4919-85ad-776cf6af0485');
INSERT INTO "image" ("id", "imageUrl", "websiteId") VALUES ('310bcb92-83a7-48fe-802e-315e1ec6357f', 'https://i.imgur.com/YfJQV5z.png?id=165', '44b2b1f1-5c96-4d7f-ad65-793383243fcd');
INSERT INTO "image" ("id", "imageUrl", "websiteId") VALUES ('e775a9ec-872d-4a75-aea4-da0f1ea76422', 'https://i.imgur.com/YfJQV5z.png?id=167', '1dd324e5-73ec-4642-bee7-f316589e9286');
INSERT INTO "image" ("id", "imageUrl", "websiteId") VALUES ('09fc51cb-f889-46f4-b7be-63c96e7f429f', 'https://i.imgur.com/YfJQV5z.png?id=169', '8f17f180-0463-4402-85d2-61deacc2a53c');
INSERT INTO "image" ("id", "imageUrl", "websiteId") VALUES ('67909401-241e-4a3f-8fce-80c5beb47d30', 'https://i.imgur.com/YfJQV5z.png?id=171', 'b23c859c-edee-49d9-b4e4-f56afd080db5');
INSERT INTO "image" ("id", "imageUrl", "websiteId") VALUES ('9a3a38b9-819a-4178-b28b-e7df2780a5db', 'https://i.imgur.com/YfJQV5z.png?id=173', '5aebe921-3705-49a3-b60b-aeb343dd896f');
INSERT INTO "image" ("id", "imageUrl", "websiteId") VALUES ('e4c9feeb-731f-4c6a-9c37-09139aca501a', 'https://i.imgur.com/YfJQV5z.png?id=175', '44b2b1f1-5c96-4d7f-ad65-793383243fcd');
INSERT INTO "image" ("id", "imageUrl", "websiteId") VALUES ('7ea050f1-250c-4fa1-aa38-c0fb6cb55628', 'https://i.imgur.com/YfJQV5z.png?id=177', '1dd324e5-73ec-4642-bee7-f316589e9286');
INSERT INTO "image" ("id", "imageUrl", "websiteId") VALUES ('c0b79eea-e4e9-4f16-8a29-a72e79977f7b', 'https://i.imgur.com/YfJQV5z.png?id=179', '628e6d8d-85c1-41ec-a2ea-27ced856f591');
    `,
      )
    } catch (error) {
      // ignore
    }
  }

  public async down(queryRunner: QueryRunner): Promise<void> {}
}
