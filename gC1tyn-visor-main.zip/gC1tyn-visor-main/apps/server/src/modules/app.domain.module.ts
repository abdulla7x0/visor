import { Module } from '@nestjs/common'
import { AuthenticationDomainModule } from './authentication/domain'
import { AuthorizationDomainModule } from './authorization/domain'

import { UserDomainModule } from './user/domain'

import { NotificationDomainModule } from './notification/domain'

import { WebsiteDomainModule } from './website/domain'

import { ImageDomainModule } from './image/domain'

@Module({
  imports: [
    AuthenticationDomainModule,
    AuthorizationDomainModule,
    UserDomainModule,
    NotificationDomainModule,

    WebsiteDomainModule,

    ImageDomainModule,
  ],
  controllers: [],
  providers: [],
})
export class AppDomainModule {}
