import { Module } from '@nestjs/common'
import { AuthenticationDomainModule } from '@server/modules/authentication/domain'
import { ImageDomainModule } from '../domain'
import { ImageController } from './image.controller'

import { WebsiteDomainModule } from '../../../modules/website/domain'

import { ImageByWebsiteController } from './imageByWebsite.controller'

@Module({
  imports: [AuthenticationDomainModule, ImageDomainModule, WebsiteDomainModule],
  controllers: [ImageController, ImageByWebsiteController],
  providers: [],
})
export class ImageApplicationModule {}
