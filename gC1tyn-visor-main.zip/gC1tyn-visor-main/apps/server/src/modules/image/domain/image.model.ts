import { ColumnNumeric } from '@server/core/database'
import {
  Column,
  CreateDateColumn,
  DeleteDateColumn,
  Entity,
  JoinColumn,
  ManyToOne,
  OneToMany,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from 'typeorm'

import { Website } from '../../../modules/website/domain'

@Entity()
export class Image {
  @PrimaryGeneratedColumn('uuid')
  id: string

  @Column({ nullable: true })
  imageUrl?: string

  @Column({})
  websiteId: string

  @ManyToOne(() => Website, parent => parent.images)
  @JoinColumn({ name: 'websiteId' })
  website?: Website

  @CreateDateColumn()
  dateCreated: string

  @UpdateDateColumn()
  dateUpdated: string

  @DeleteDateColumn()
  dateDeleted: string
}
