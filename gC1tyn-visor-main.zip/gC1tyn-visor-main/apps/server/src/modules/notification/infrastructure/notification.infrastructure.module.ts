import { Module } from '@nestjs/common'
import { SocketModule } from '@server/libraries/socket'
import { AuthorizationDomainModule } from '@server/modules/authorization/domain'
import { NotificationDomainModule } from '../domain'

import { NotificationWebsiteSubscriber } from './subscribers/notification.website.subscriber'

import { NotificationImageSubscriber } from './subscribers/notification.image.subscriber'

@Module({
  imports: [AuthorizationDomainModule, NotificationDomainModule, SocketModule],
  providers: [NotificationWebsiteSubscriber, NotificationImageSubscriber],
  exports: [],
})
export class NotificationInfrastructureModule {}
