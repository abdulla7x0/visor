import { Module } from '@nestjs/common'
import { TypeOrmModule } from '@nestjs/typeorm'
import { DatabaseHelperModule } from '../../../core/database'
import { WebsiteDomainFacade } from './website.domain.facade'
import { Website } from './website.model'

@Module({
  imports: [TypeOrmModule.forFeature([Website]), DatabaseHelperModule],
  providers: [WebsiteDomainFacade, WebsiteDomainFacade],
  exports: [WebsiteDomainFacade],
})
export class WebsiteDomainModule {}
