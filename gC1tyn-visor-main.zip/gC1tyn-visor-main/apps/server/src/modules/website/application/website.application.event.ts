export namespace WebsiteApplicationEvent {
  export namespace WebsiteCreated {
    export const key = 'website.application.website.created'

    export type Payload = {
      id: string
      userId: string
    }
  }
}
