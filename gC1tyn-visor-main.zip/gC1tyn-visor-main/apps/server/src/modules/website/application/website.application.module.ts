import { Module } from '@nestjs/common'
import { AuthenticationDomainModule } from '@server/modules/authentication/domain'
import { WebsiteDomainModule } from '../domain'
import { WebsiteController } from './website.controller'

import { UserDomainModule } from '../../../modules/user/domain'

import { WebsiteByUserController } from './websiteByUser.controller'

@Module({
  imports: [AuthenticationDomainModule, WebsiteDomainModule, UserDomainModule],
  controllers: [WebsiteController, WebsiteByUserController],
  providers: [],
})
export class WebsiteApplicationModule {}
