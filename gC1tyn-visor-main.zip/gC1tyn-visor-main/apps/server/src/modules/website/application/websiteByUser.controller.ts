import { Request } from 'express'

import { Body, Controller, Get, Param, Post, Req } from '@nestjs/common'
import { RequestHelper } from '@server/helpers/request'
import { EventService } from '@server/libraries/event'
import { WebsiteDomainFacade } from '@server/modules/website/domain'
import { AuthenticationDomainFacade } from '@server/modules/authentication/domain'
import { WebsiteApplicationEvent } from './website.application.event'
import { WebsiteCreateDto } from './website.dto'

import { UserDomainFacade } from '../../user/domain'

@Controller('/v1/users')
export class WebsiteByUserController {
  constructor(
    private userDomainFacade: UserDomainFacade,

    private websiteDomainFacade: WebsiteDomainFacade,
    private eventService: EventService,
    private authenticationDomainFacade: AuthenticationDomainFacade,
  ) {}

  @Get('/user/:userId/websites')
  async findManyUserId(
    @Param('userId') userId: string,
    @Req() request: Request,
  ) {
    const queryOptions = RequestHelper.getQueryOptions(request)

    const parent = await this.userDomainFacade.findOneByIdOrFail(userId)

    const items = await this.websiteDomainFacade.findManyByUser(
      parent,
      queryOptions,
    )

    return items
  }

  @Post('/user/:userId/websites')
  async createByUserId(
    @Param('userId') userId: string,
    @Body() body: WebsiteCreateDto,
    @Req() request: Request,
  ) {
    const { user } = this.authenticationDomainFacade.getRequestPayload(request)

    const valuesUpdated = { ...body, userId }

    const item = await this.websiteDomainFacade.create(valuesUpdated)

    await this.eventService.emit<WebsiteApplicationEvent.WebsiteCreated.Payload>(
      WebsiteApplicationEvent.WebsiteCreated.key,
      {
        id: item.id,
        userId: user.id,
      },
    )

    return item
  }
}
