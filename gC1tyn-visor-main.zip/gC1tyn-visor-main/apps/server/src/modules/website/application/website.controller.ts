import { Request } from 'express'

import {
  Body,
  Controller,
  Delete,
  Get,
  Param,
  Patch,
  Post,
  Req,
} from '@nestjs/common'
import { EventService } from '@server/libraries/event'
import { Website, WebsiteDomainFacade } from '@server/modules/website/domain'
import { AuthenticationDomainFacade } from '@server/modules/authentication/domain'
import { RequestHelper } from '../../../helpers/request'
import { WebsiteApplicationEvent } from './website.application.event'
import { WebsiteCreateDto, WebsiteUpdateDto } from './website.dto'

@Controller('/v1/websites')
export class WebsiteController {
  constructor(
    private eventService: EventService,
    private websiteDomainFacade: WebsiteDomainFacade,
    private authenticationDomainFacade: AuthenticationDomainFacade,
  ) {}

  @Get('/')
  async findMany(@Req() request: Request) {
    const queryOptions = RequestHelper.getQueryOptions(request)

    const items = await this.websiteDomainFacade.findMany(queryOptions)

    return items
  }

  @Post('/')
  async create(@Body() body: WebsiteCreateDto, @Req() request: Request) {
    const { user } = this.authenticationDomainFacade.getRequestPayload(request)

    const item = await this.websiteDomainFacade.create(body)

    await this.eventService.emit<WebsiteApplicationEvent.WebsiteCreated.Payload>(
      WebsiteApplicationEvent.WebsiteCreated.key,
      {
        id: item.id,
        userId: user.id,
      },
    )

    return item
  }

  @Get('/:websiteId')
  async findOne(
    @Param('websiteId') websiteId: string,
    @Req() request: Request,
  ) {
    const queryOptions = RequestHelper.getQueryOptions(request)

    const item = await this.websiteDomainFacade.findOneByIdOrFail(
      websiteId,
      queryOptions,
    )

    return item
  }

  @Patch('/:websiteId')
  async update(
    @Param('websiteId') websiteId: string,
    @Body() body: WebsiteUpdateDto,
  ) {
    const item = await this.websiteDomainFacade.findOneByIdOrFail(websiteId)

    const itemUpdated = await this.websiteDomainFacade.update(
      item,
      body as Partial<Website>,
    )
    return itemUpdated
  }

  @Delete('/:websiteId')
  async delete(@Param('websiteId') websiteId: string) {
    const item = await this.websiteDomainFacade.findOneByIdOrFail(websiteId)

    await this.websiteDomainFacade.delete(item)

    return item
  }
}
