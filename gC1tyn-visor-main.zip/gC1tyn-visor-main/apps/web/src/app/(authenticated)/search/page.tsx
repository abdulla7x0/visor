'use client'

import { Typography, Input, Button, Card, Col, Row, Avatar } from 'antd'
import { SearchOutlined } from '@ant-design/icons'
import { useEffect, useState } from 'react'
const { Title, Text } = Typography
import { useAuthentication } from '@web/modules/authentication'
import dayjs from 'dayjs'
import { useSnackbar } from 'notistack'
import { useRouter, useParams } from 'next/navigation'
import { Api, Model } from '@web/domain'
import { PageLayout } from '@web/layouts/Page.layout'

export default function SearchResultsPage() {
  const router = useRouter()
  const params = useParams<any>()
  const authentication = useAuthentication()
  const userId = authentication.user?.id
  const { enqueueSnackbar } = useSnackbar()
  const [searchQuery, setSearchQuery] = useState('')
  const [websites, setWebsites] = useState<Model.Website[]>([])
  const [loading, setLoading] = useState(false)

  useEffect(() => {
    if (params.query) {
      setSearchQuery(params.query)
      fetchWebsites(params.query)
    }
  }, [params.query])

  const fetchWebsites = async (query: string) => {
    setLoading(true)
    try {
      const websitesFound = await Api.Website.findMany({
        filters: { description: { ilike: query } },
        includes: ['user', 'images'],
      })
      setWebsites(websitesFound)
      setLoading(false)
    } catch (error) {
      enqueueSnackbar('Failed to fetch websites', { variant: 'error' })
      setLoading(false)
    }
  }

  const handleSearch = () => {
    router.push(`/search?query=${searchQuery}`)
  }

  return (
    <PageLayout layout="narrow">
      <Title level={2}>Search Results</Title>
      <Text type="secondary">
        Find the best websites related to your query.
      </Text>
      <Input
        placeholder="Search websites..."
        prefix={<SearchOutlined />}
        value={searchQuery}
        onChange={e => setSearchQuery(e.target.value)}
        onPressEnter={handleSearch}
        style={{ margin: '20px 0' }}
      />
      <Button type="primary" onClick={handleSearch} loading={loading}>
        Search
      </Button>
      <Row gutter={[16, 16]} style={{ marginTop: 20 }}>
        {websites?.map(website => (
          <Col key={website.id} xs={24} sm={12} md={8} lg={6}>
            <Card
              hoverable
              onClick={() => router.push(`/website/${website.id}`)}
              cover={
                website.images?.[0] && (
                  <img alt="example" src={website.images[0].imageUrl} />
                )
              }
            >
              <Card.Meta
                avatar={<Avatar src={website.user?.pictureUrl} />}
                title={website.url}
                description={website.description}
              />
              <Text
                type="secondary"
                style={{ display: 'block', marginTop: '10px' }}
              >
                Created: {dayjs(website.dateCreated).format('DD MMM YYYY')}
              </Text>
            </Card>
          </Col>
        ))}
      </Row>
    </PageLayout>
  )
}
