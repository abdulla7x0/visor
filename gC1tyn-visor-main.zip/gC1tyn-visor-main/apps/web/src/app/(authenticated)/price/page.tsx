'use client'

import React from 'react';
import { Typography, Row, Col, Card } from 'antd';

const { Title, Text } = Typography;

export default function PricePage() {
  return (
    <div style={{ padding: '20px' }}>
      <Title level={2}>Price Comparison</Title>
      <Row gutter={16}>
        <Col span={12}>
          <Card title="Price Box 1" bordered={false}>
            <Text>Placeholder text for Price Box 1</Text>
          </Card>
        </Col>
        <Col span={12}>
          <Card title="Price Box 2" bordered={false}>
            <Text>Placeholder text for Price Box 2</Text>
          </Card>
        </Col>
      </Row>
    </div>
  );
}
