'use client'

import React, { useState } from 'react'
import { Button, Form, Input, Upload, Typography, Modal } from 'antd'
import { PlusOutlined } from '@ant-design/icons'
const { Title, Text } = Typography
import { useAuthentication } from '@web/modules/authentication'
import dayjs from 'dayjs'
import { useSnackbar } from 'notistack'
import { useRouter, useParams } from 'next/navigation'
import { Api, Model } from '@web/domain'
import { PageLayout } from '@web/layouts/Page.layout'

export default function UploadWebsitePage() {
  const [form] = Form.useForm()
  const router = useRouter()
  const { enqueueSnackbar } = useSnackbar()
  const authentication = useAuthentication()
  const userId = authentication.user?.id
  const [fileList, setFileList] = useState([])
  const [previewVisible, setPreviewVisible] = useState(false)
  const [previewImage, setPreviewImage] = useState('')

  const handleUpload = async options => {
    const { file } = options
    try {
      const url = await Api.Upload.upload(file)
      setFileList(fileList => [
        ...fileList,
        { url: url, status: 'done', uid: file.uid },
      ])
      enqueueSnackbar('Image uploaded successfully!', { variant: 'success' })
    } catch (error) {
      enqueueSnackbar('Failed to upload image.', { variant: 'error' })
    }
  }

  const handleSubmit = async values => {
    try {
      const newWebsite = await Api.Website.createOneByUserId(userId, {
        url: values.url,
        description: values.description,
      })
      fileList.forEach(async file => {
        await Api.Image.createOneByWebsiteId(newWebsite.id, {
          imageUrl: file.url,
        })
      })
      enqueueSnackbar('Website and images uploaded successfully!', {
        variant: 'success',
      })
      router.push('/home')
    } catch (error) {
      enqueueSnackbar('Failed to upload website details.', { variant: 'error' })
    }
  }

  const handlePreview = async file => {
    setPreviewImage(file.url || file.thumbUrl)
    setPreviewVisible(true)
  }

  const uploadButton = (
    <div>
      <PlusOutlined />
      <div style={{ marginTop: 8 }}>Upload</div>
    </div>
  )

  return (
    <PageLayout layout="narrow">
      <Title level={2}>Upload Your Website</Title>
      <Text type="secondary">
        Share details and images of your websites with the world.
      </Text>
      <Form form={form} layout="vertical" onFinish={handleSubmit}>
        <Form.Item
          name="url"
          label="Website URL"
          rules={[
            { required: true, message: 'Please input your website URL!' },
          ]}
        >
          <Input placeholder="https://example.com" />
        </Form.Item>
        <Form.Item
          name="description"
          label="Description"
          rules={[{ required: true, message: 'Please input a description!' }]}
        >
          <Input.TextArea rows={4} placeholder="Describe your website" />
        </Form.Item>
        <Form.Item label="Upload Images">
          <Upload
            listType="picture-card"
            fileList={fileList}
            onPreview={handlePreview}
            customRequest={handleUpload}
            accept="image/*"
          >
            {fileList.length >= 8 ? null : uploadButton}
          </Upload>
          <Modal
            visible={previewVisible}
            footer={null}
            onCancel={() => setPreviewVisible(false)}
          >
            <img alt="example" style={{ width: '100%' }} src={previewImage} />
          </Modal>
        </Form.Item>
        <Form.Item>
          <Button type="primary" htmlType="submit">
            Submit
          </Button>
        </Form.Item>
      </Form>
    </PageLayout>
  )
}
