'use client'

import { useEffect, useState } from 'react'
import { Card, Col, Row, Typography } from 'antd'
import { EyeOutlined } from '@ant-design/icons'
const { Title, Text } = Typography
import { useAuthentication } from '@web/modules/authentication'
import dayjs from 'dayjs'
import { useSnackbar } from 'notistack'
import { useRouter, useParams } from 'next/navigation'
import { Api, Model } from '@web/domain'
import { PageLayout } from '@web/layouts/Page.layout'

export default function HomePage() {
  const router = useRouter()
  const authentication = useAuthentication()
  const { enqueueSnackbar } = useSnackbar()
  const [websites, setWebsites] = useState([])

  useEffect(() => {
    const fetchWebsites = async () => {
      try {
        const websitesFound = await Api.Website.findMany({
          includes: ['user', 'images'],
        })
        setWebsites(websitesFound)
      } catch (error) {
        enqueueSnackbar('Failed to fetch websites', { variant: 'error' })
      }
    }

    fetchWebsites()
  }, [])

  const handleCardClick = websiteId => {
    router.push(`/website/${websiteId}`)
  }

  return (
    <PageLayout layout="narrow">
      <Title level={2}>Explore Websites</Title>
      <Text>Discover websites uploaded by other users.</Text>
      <Row gutter={[16, 16]} style={{ marginTop: 20 }}>
        {websites?.map(website => (
          <Col key={website.id} xs={24} sm={12} md={8} lg={6}>
            <Card
              hoverable
              cover={
                <img
                  alt="example"
                  src={
                    website.images?.[0]?.imageUrl ||
                    'https://via.placeholder.com/150'
                  }
                />
              }
              onClick={() => handleCardClick(website.id)}
              actions={[<EyeOutlined key="view" />]}
            >
              <Card.Meta
                title={website.user?.name || 'Unknown User'}
                description={website.description || 'No description provided.'}
              />
            </Card>
          </Col>
        ))}
      </Row>
    </PageLayout>
  )
}
