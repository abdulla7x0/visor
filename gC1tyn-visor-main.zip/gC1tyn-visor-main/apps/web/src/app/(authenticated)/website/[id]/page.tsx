'use client'

import { useEffect, useState } from 'react'
import { Typography, Card, Avatar, Space, Image as AntImage, Grid } from 'antd'
import { UserOutlined } from '@ant-design/icons'
const { Title, Text, Paragraph } = Typography
const { useBreakpoint } = Grid
import { useAuthentication } from '@web/modules/authentication'
import dayjs from 'dayjs'
import { useSnackbar } from 'notistack'
import { useRouter, useParams } from 'next/navigation'
import { Api, Model } from '@web/domain'
import { PageLayout } from '@web/layouts/Page.layout'

export default function WebsiteDetailsPage() {
  const router = useRouter()
  const params = useParams<any>()
  const authentication = useAuthentication()
  const { enqueueSnackbar } = useSnackbar()
  const screens = useBreakpoint()

  const [website, setWebsite] = useState<Model.Website | null>(null)

  useEffect(() => {
    const fetchWebsite = async () => {
      try {
        const websiteData = await Api.Website.findOne(params.id, {
          includes: ['user', 'images'],
        })
        setWebsite(websiteData)
      } catch (error) {
        enqueueSnackbar('Failed to fetch website details', { variant: 'error' })
      }
    }

    if (params.id) {
      fetchWebsite()
    }
  }, [params.id])

  return (
    <PageLayout layout="narrow">
      <Title level={2}>Website Details</Title>
      <Paragraph>
        This page displays detailed information about a specific website.
      </Paragraph>
      {website ? (
        <Card
          style={{ maxWidth: screens.md ? '80%' : '100%', margin: 'auto' }}
          actions={[
            <Text onClick={() => router.push('/home')} key="goHome">
              Go Home
            </Text>,
            <Text onClick={() => router.push(`/upload`)} key="uploadMore">
              Upload More
            </Text>,
          ]}
        >
          <Card.Meta
            avatar={
              <Avatar
                src={website.user?.pictureUrl || undefined}
                icon={<UserOutlined />}
              />
            }
            title={website.url}
            description={website.description}
          />
          <Space
            direction="vertical"
            size="middle"
            style={{ width: '100%', marginTop: 20 }}
          >
            <Text>
              <strong>User:</strong> {website.user?.name || 'Unknown'}
            </Text>
            <Text>
              <strong>Created:</strong>{' '}
              {dayjs(website.dateCreated).format('DD MMM YYYY')}
            </Text>
            <Text>
              <strong>Last Updated:</strong>{' '}
              {dayjs(website.dateUpdated).format('DD MMM YYYY')}
            </Text>
            {website.images?.map((image, index) => (
              <AntImage
                key={index}
                src={image.imageUrl}
                alt={`Image ${index + 1}`}
                style={{ maxWidth: '100%' }}
              />
            ))}
          </Space>
        </Card>
      ) : (
        <Text>Loading...</Text>
      )}
    </PageLayout>
  )
}
