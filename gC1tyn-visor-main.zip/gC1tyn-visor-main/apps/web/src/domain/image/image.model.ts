import { Website } from '../website'

export class Image {
  id: string

  imageUrl?: string

  websiteId: string

  website?: Website

  dateCreated: string

  dateDeleted: string

  dateUpdated: string
}
