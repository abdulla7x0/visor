import { HttpService } from '../../core/http'
import { ApiHelper } from '../helpers/api.helper'
import { Website } from './website.model'

export class WebsiteApi {
  static findMany(
    queryOptions?: ApiHelper.QueryOptions<Website>,
  ): Promise<Website[]> {
    const buildOptions = ApiHelper.buildQueryOptions(queryOptions)

    return HttpService.api.get(`/v1/websites${buildOptions}`)
  }

  static findOne(
    websiteId: string,
    queryOptions?: ApiHelper.QueryOptions<Website>,
  ): Promise<Website> {
    const buildOptions = ApiHelper.buildQueryOptions(queryOptions)

    return HttpService.api.get(`/v1/websites/${websiteId}${buildOptions}`)
  }

  static createOne(values: Partial<Website>): Promise<Website> {
    return HttpService.api.post(`/v1/websites`, values)
  }

  static updateOne(
    websiteId: string,
    values: Partial<Website>,
  ): Promise<Website> {
    return HttpService.api.patch(`/v1/websites/${websiteId}`, values)
  }

  static deleteOne(websiteId: string): Promise<void> {
    return HttpService.api.delete(`/v1/websites/${websiteId}`)
  }

  static findManyByUserId(
    userId: string,
    queryOptions?: ApiHelper.QueryOptions<Website>,
  ): Promise<Website[]> {
    const buildOptions = ApiHelper.buildQueryOptions(queryOptions)

    return HttpService.api.get(
      `/v1/users/user/${userId}/websites${buildOptions}`,
    )
  }

  static createOneByUserId(
    userId: string,
    values: Partial<Website>,
  ): Promise<Website> {
    return HttpService.api.post(`/v1/users/user/${userId}/websites`, values)
  }
}
