import { User } from '../user'

import { Image } from '../image'

export class Website {
  id: string

  url?: string

  description?: string

  userId: string

  user?: User

  dateCreated: string

  dateDeleted: string

  dateUpdated: string

  images?: Image[]
}
